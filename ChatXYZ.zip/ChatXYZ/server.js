const path = require("path");
const express = require("express");
const dotenv = require("dotenv");
const session = require("express-session");
const passport = require("passport");
const { Strategy: GoogleStrategy } = require("passport-google-oauth20");
const { GoogleGenerativeAI } = require("@google/generative-ai");

dotenv.config();

const app = express();
const port = Number(process.env.PORT) || 3000;
const defaultGoogleModel = process.env.GOOGLE_MODEL || "gemini-2.5-flash";
const ALLOWED_MODELS = ["gemini-2.5-flash"];
const IMAGEN_MODEL = "imagen-4.0-generate-001";

const systemPrompt = "You are ChatXYZ, a highly capable AI assistant created by Group❤️Chetan. " +
  "You are helpful, friendly, and can assist with a wide range of tasks, from coding to writing. " +
  "If anyone asks who made you, tell them you were created by Group❤️Chetan. Keep answers clear and helpful.";

const googleClient = process.env.GOOGLE_API_KEY ? new GoogleGenerativeAI(process.env.GOOGLE_API_KEY) : null;

// ── Sessions ──────────────────────────────────────────────────────
app.use(express.json({ limit: "4mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
  secret: process.env.SESSION_SECRET || "chatxyz-super-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 7 * 24 * 60 * 60 * 1000,
    sameSite: "lax",
    secure: false
  }
}));

// ── Passport / Google OAuth ───────────────────────────────────────
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.CALLBACK_URL || "/auth/google/callback"
    },
    (_at, _rt, profile, done) => done(null, {
      id: profile.id,
      name: profile.displayName,
      email: profile.emails?.[0]?.value || "",
      picture: profile.photos?.[0]?.value || "",
      provider: "google"
    })
  ));
}

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user, done) => done(null, user));

app.use(passport.initialize());
app.use(passport.session());

// ── Auth Routes ───────────────────────────────────────────────────
app.get("/auth/google", (req, res, next) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return res.redirect("/?auth=not-configured");
  }
  passport.authenticate("google", { scope: ["profile", "email"] })(req, res, next);
});

app.get("/auth/google/callback",
  passport.authenticate("google", { failureRedirect: "/?auth=failed" }),
  (req, res) => res.redirect("/?auth=success")
);

app.get("/api/me", (req, res) => {
  if (req.user) {
    res.json({ loggedIn: true, user: req.user });
  } else {
    res.json({ loggedIn: false });
  }
});

app.post("/api/logout", (req, res) => {
  req.logout(err => {
    if (err) return res.status(500).json({ error: "Logout failed" });
    req.session.destroy(() => res.json({ ok: true }));
  });
});

// ── Config ────────────────────────────────────────────────────────
app.get("/api/config", (_req, res) => {
  res.json({
    provider: "google",
    googleConfigured: Boolean(process.env.GOOGLE_API_KEY),
    models: ALLOWED_MODELS,
    defaultModel: defaultGoogleModel,
    imageModel: IMAGEN_MODEL,
    googleAuthReady: Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET)
  });
});

// ── Chat ──────────────────────────────────────────────────────────
app.post("/api/chat", async (req, res) => {
  const messages = sanitizeMessages(req.body?.messages);
  const requestedModel = req.body?.model;
  const googleModel = ALLOWED_MODELS.includes(requestedModel) ? requestedModel : defaultGoogleModel;

  if (!messages.length) return res.status(400).json({ error: "messages must contain at least one user message." });

  try {
    if (!googleClient) return res.status(400).json({ error: "GOOGLE_API_KEY is missing. Add it to .env." });

    const geminiModel = googleClient.getGenerativeModel({
      model: googleModel,
      systemInstruction: systemPrompt
    });

    const historyMessages = messages.slice(0, -1);
    const cleanHistory = [];
    let expectedRole = "user";

    for (const msg of historyMessages) {
      const geminiRole = msg.role === "assistant" ? "model" : "user";
      if (geminiRole === expectedRole) {
        cleanHistory.push({ role: geminiRole, parts: [{ text: msg.content }] });
        expectedRole = expectedRole === "user" ? "model" : "user";
      }
    }

    const geminiChat = geminiModel.startChat({ history: cleanHistory });
    const lastMessage = messages[messages.length - 1];

    if (!lastMessage?.content) return res.status(400).json({ error: "Empty message." });

    const result = await geminiChat.sendMessage(lastMessage.content);
    const reply = result.response.text();
    if (!reply) throw new Error("Gemini returned an empty response.");

    return res.json({ reply, provider: "google", model: googleModel });
  } catch (error) {
    console.error("Chat error:", error);
    return res.status(500).json({ error: error.message || "Unknown server error." });
  }
});

// ── Image Generation (Pollinations — free, no key needed) ─────────
app.post("/api/generate-image", async (req, res) => {
  const prompt = req.body?.prompt?.trim();
  if (!prompt) return res.status(400).json({ error: "A prompt is required." });

  try {
    const encodedPrompt = encodeURIComponent(prompt);
    const url = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=768&height=768&model=flux&nologo=true`;

    const response = await fetch(url, {
      headers: { "User-Agent": "ChatXYZ/1.0" }
    });

    if (!response.ok) throw new Error(`Pollinations error (${response.status})`);

    const arrayBuffer = await response.arrayBuffer();
    const imageBase64 = Buffer.from(arrayBuffer).toString("base64");
    const mimeType = response.headers.get("content-type") || "image/jpeg";

    return res.json({ imageBase64, mimeType, model: "Pollinations (Flux)" });
  } catch (error) {
    console.error("Image generation error:", error);
    return res.status(500).json({ error: error.message || "Image generation failed." });
  }
});

// ── Helpers ───────────────────────────────────────────────────────
function sanitizeMessages(input) {
  if (!Array.isArray(input)) return [];
  return input
    .filter(item =>
      item &&
      (item.role === "user" || item.role === "assistant") &&
      typeof item.content === "string" &&
      item.content.trim().length > 0
    )
    .map(item => ({ role: item.role, content: item.content.trim() }))
    .slice(-20);
}

app.listen(port, () => {
  console.log(`ChatXYZ running on http://localhost:${port}`);
  if (!process.env.GOOGLE_CLIENT_ID) {
    console.log("⚠ GOOGLE_CLIENT_ID not set — Google Sign-In will be disabled.");
    console.log(" Get one at: https://console.cloud.google.com/apis/credentials");
  }
});

module.exports = app;
