// ─────────────────────────────────────────────────────────────────
// ChatXYZ — app.js  (auth + chat + image generation)
// ─────────────────────────────────────────────────────────────────

const GUEST_LIMIT = 5;
const STORAGE_USER = "chatxyz_user";
const STORAGE_STATS = "chatxyz_stats";

// ── DOM refs ──────────────────────────────────────────────────────
const chatEl = document.getElementById("chat");
const form = document.getElementById("chat-form");
const inputEl = document.getElementById("message-input");
const statusBox = document.getElementById("status");
const sendBtn = document.getElementById("send-btn");
const modelSelect = document.getElementById("model-select");

const loginModal = document.getElementById("login-modal");
const guestRemaining = document.getElementById("guest-remaining");
const guestSkipBtn = document.getElementById("guest-continue-btn");
const emailSigninBtn = document.getElementById("email-signin-btn");
const modalName = document.getElementById("modal-name");
const modalEmail = document.getElementById("modal-email");
const modalError = document.getElementById("modal-error");

const profilePanel = document.getElementById("profile-panel");
const ppClose = document.getElementById("pp-close-btn");
const ppAvatar = document.getElementById("pp-avatar");
const ppName = document.getElementById("pp-name");
const ppEmail = document.getElementById("pp-email");
const ppBadge = document.getElementById("pp-badge");
const ppMsgCount = document.getElementById("pp-msg-count");
const ppImgCount = document.getElementById("pp-img-count");
const avatarInput = document.getElementById("avatar-file-input");
const signoutBtn = document.getElementById("signout-btn");

const headerLoginBtn = document.getElementById("header-login-btn");
const headerProfileBtn = document.getElementById("header-profile-btn");
const headerAvatar = document.getElementById("header-avatar");
const guestCounter = document.getElementById("guest-counter");
const guestCountDisp = document.getElementById("guest-count-display");

// ── State ─────────────────────────────────────────────────────────
let currentUser = null;  // null = guest
let guestUsed = 0;
let stats = { msgs: 0, imgs: 0 };
let canClose = false; // true when user opened modal manually (not forced by limit)
const messages = [];

// ── Init ──────────────────────────────────────────────────────────
async function init() {
  // Load stats & guest count from localStorage
  try { stats = JSON.parse(localStorage.getItem(STORAGE_STATS) || "{}"); } catch { }
  guestUsed = parseInt(localStorage.getItem("chatxyz_guest_used") || "0", 10);
  stats.msgs = stats.msgs || 0;
  stats.imgs = stats.imgs || 0;

  // ── Always check server session first (handles Google OAuth redirect) ──
  try {
    const res = await fetch("/api/me");
    const data = await res.json();
    if (data.loggedIn && data.user) {
      currentUser = data.user;
      // Keep localStorage in sync for offline display
      localStorage.setItem(STORAGE_USER, JSON.stringify(currentUser));
    } else {
      // Fall back to localStorage (email login)
      const raw = localStorage.getItem(STORAGE_USER);
      if (raw) try { currentUser = JSON.parse(raw); } catch { }
    }
  } catch {
    // Server offline – fall back to localStorage
    const raw = localStorage.getItem(STORAGE_USER);
    if (raw) try { currentUser = JSON.parse(raw); } catch { }
  }

  // ── Handle OAuth redirect params ──────────────────────────────────
  const params = new URLSearchParams(window.location.search);
  const authStatus = params.get("auth");
  if (authStatus) {
    // Clean up URL
    window.history.replaceState({}, "", window.location.pathname);
    if (authStatus === "failed") {
      addMessage("assistant", "⚠️ Google sign-in failed. Please try again.");
    } else if (authStatus === "not-configured") {
      addMessage("assistant", "⚠️ Google login is not yet configured. Please use email login.");
    }
  }

  updateAuthUI();
  initGoogleSignIn();

  addMessage("assistant",
    "Hello! I am ChatXYZ \u2764\uFE0F\n\nI can answer questions, help with code, summarize text, and generate images.\n\nTip: Type \u2018Generate image of\u2026\u2019 to create AI art!"
  );

  if (authStatus === "success" && currentUser) {
    addMessage("assistant", `Welcome, ${currentUser.name}! 🎉 You now have unlimited access.`);
  }

  loadConfig();

}

// ── Google Sign-In ────────────────────────────────────────────────
function initGoogleSignIn() {
  const clientIdMeta = document.querySelector('meta[name="google-client-id"]');
  const clientId = clientIdMeta?.content || "";
  if (!clientId || clientId.includes("YOUR_GOOGLE")) return; // not configured

  window.handleGoogleCredential = function (response) {
    const payload = parseJwt(response.credential);
    if (!payload) return;
    signIn({
      name: payload.name,
      email: payload.email,
      picture: payload.picture,
      provider: "google"
    });
  };

  try {
    google.accounts.id.initialize({
      client_id: clientId,
      callback: "handleGoogleCredential"
    });
    google.accounts.id.renderButton(
      document.getElementById("google-btn-container"),
      { theme: "outline", size: "large", width: 340, text: "signin_with", shape: "pill" }
    );
  } catch { }
}

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
  } catch { return null; }
}

// ── Auth actions ──────────────────────────────────────────────────
function signIn(user) {
  currentUser = user;
  localStorage.setItem(STORAGE_USER, JSON.stringify(user));
  localStorage.removeItem("chatxyz_guest_used");
  guestUsed = 0;
  closeModal();
  updateAuthUI();
  addMessage("assistant", `Welcome, ${user.name}! You now have unlimited access \uD83C\uDF89`);
}

function signOut() {
  currentUser = null;
  guestUsed = 0;
  stats = { msgs: 0, imgs: 0 };
  localStorage.removeItem(STORAGE_USER);
  localStorage.removeItem(STORAGE_STATS);
  localStorage.removeItem("chatxyz_guest_used");
  // Also clear server session
  fetch("/api/logout", { method: "POST" }).catch(() => { });
  profilePanel.hidden = true;
  updateAuthUI();
  messages.length = 0;
  chatEl.innerHTML = "";
  addMessage("assistant", "You have been signed out. You can send 5 messages as a guest.");
}

// ── Auth UI ───────────────────────────────────────────────────────
function updateAuthUI() {
  if (currentUser) {
    closeModal();  // always close modal when logged in
    headerLoginBtn.hidden = true;
    headerProfileBtn.hidden = false;
    guestCounter.hidden = true;

    const pic = currentUser.picture || generateAvatar(currentUser.name);
    headerAvatar.src = pic;
    ppAvatar.src = pic;
    ppName.textContent = currentUser.name;
    ppEmail.textContent = currentUser.email;
    ppBadge.textContent = currentUser.provider === "google" ? "🔵 Google" : "✉️ Email";
  } else {
    headerLoginBtn.hidden = false;
    headerProfileBtn.hidden = true;
    guestCounter.hidden = false;
    updateGuestCounter();
  }
  updateStats();
}


function updateGuestCounter() {
  const left = Math.max(0, GUEST_LIMIT - guestUsed);
  guestCountDisp.textContent = left;
  guestRemaining.textContent = left;
}

function updateStats() {
  ppMsgCount.textContent = stats.msgs;
  ppImgCount.textContent = stats.imgs;
}

function saveStats() {
  localStorage.setItem(STORAGE_STATS, JSON.stringify(stats));
}

// ── Avatar helpers ────────────────────────────────────────────────
function generateAvatar(name = "U") {
  const initials = name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#4f46e5";
  ctx.fillRect(0, 0, 64, 64);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 26px Outfit, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(initials, 32, 33);
  return canvas.toDataURL();
}

// ── Modal open / close ───────────────────────────────────────────
const modalBackBtn = document.getElementById("modal-back-btn");

function openModal(manual = false) {
  canClose = manual;
  // Show/hide back button based on whether user can dismiss
  if (modalBackBtn) modalBackBtn.hidden = !manual;
  // If forced (limit hit), also hide guest skip btn
  if (guestSkipBtn) guestSkipBtn.hidden = (guestUsed >= GUEST_LIMIT);
  updateGuestCounter();
  loginModal.classList.add("active");
}
function closeModal() {
  loginModal.classList.remove("active");
}

// ── Modal events ───────────────────────────────────────────────
headerLoginBtn.addEventListener("click", () => openModal(true));
if (modalBackBtn) modalBackBtn.addEventListener("click", closeModal);

guestSkipBtn.addEventListener("click", () => {
  if (guestUsed >= GUEST_LIMIT) return;
  closeModal();
});

emailSigninBtn.addEventListener("click", () => {
  const name = modalName.value.trim();
  const email = modalEmail.value.trim();
  modalError.textContent = "";
  if (!name) { modalError.textContent = "Please enter your name."; return; }
  if (!email || !email.includes("@")) { modalError.textContent = "Please enter a valid email."; return; }
  signIn({ name, email, provider: "email" });
});

[modalName, modalEmail].forEach(el => {
  el.addEventListener("keydown", e => { if (e.key === "Enter") emailSigninBtn.click(); });
});

// ── Profile panel ─────────────────────────────────────────────────
headerProfileBtn.addEventListener("click", () => {
  profilePanel.hidden = !profilePanel.hidden;
});
ppClose.addEventListener("click", () => { profilePanel.hidden = true; });
signoutBtn.addEventListener("click", () => { profilePanel.hidden = true; signOut(); });

// Click outside to close
document.addEventListener("click", e => {
  if (!profilePanel.hidden &&
    !profilePanel.contains(e.target) &&
    !headerProfileBtn.contains(e.target)) {
    profilePanel.hidden = true;
  }
});

// Photo upload
avatarInput.addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    const base64 = ev.target.result;
    if (currentUser) {
      currentUser.picture = base64;
      localStorage.setItem(STORAGE_USER, JSON.stringify(currentUser));
    }
    ppAvatar.src = base64;
    headerAvatar.src = base64;
  };
  reader.readAsDataURL(file);
});

// ── Form submit ───────────────────────────────────────────────────
form.addEventListener("submit", async e => {
  e.preventDefault();
  const text = inputEl.value.trim();
  if (!text) return;

  // Guest limit check
  if (!currentUser) {
    if (guestUsed >= GUEST_LIMIT) {
      openModal();
      return;
    }
    guestUsed++;
    localStorage.setItem("chatxyz_guest_used", guestUsed);
    updateGuestCounter();
  }

  inputEl.value = "";
  sendBtn.disabled = true;

  if (isImageRequest(text)) {
    addMessage("user", text);
    await handleImageRequest(text);
  } else {
    addMessage("user", text);
    await handleChatRequest(text);
  }

  sendBtn.disabled = false;
  inputEl.focus();
});

// ── Image request detection ───────────────────────────────────────
const IMAGE_TRIGGERS = [
  /^generate image\b/i, /^create image\b/i, /^draw\b/i,
  /^make image\b/i, /^paint\b/i, /^imagine\b/i,
  /^visualize\b/i, /^generate a picture\b/i, /^create a picture\b/i,
];
function isImageRequest(text) {
  return IMAGE_TRIGGERS.some(re => re.test(text.trim()));
}

// ── Chat request ──────────────────────────────────────────────────
async function handleChatRequest(text) {
  const typingEl = addMessage("assistant", "Thinking…", { persist: false });
  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages, model: modelSelect.value })
    });
    const data = await res.json();
    typingEl.remove();

    if (!res.ok) {
      addMessage("assistant", friendlyError(data.error));
      return;
    }

    addMessage("assistant", data.reply);
    stats.msgs++;
    saveStats();
    updateStats();
    statusBox.textContent = "✦ Gemini 2.5 Flash";
  } catch (err) {
    typingEl.remove();
    addMessage("assistant", `\u26A0\uFE0F Network error: ${err.message}`);
  }
}

// ── Image request ─────────────────────────────────────────────────
async function handleImageRequest(prompt) {
  const typingEl = addMessage("assistant", "\uD83C\uDFA8 Generating image…", { persist: false });
  try {
    const res = await fetch("/api/generate-image", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    typingEl.remove();

    if (!res.ok) {
      addMessage("assistant", `Image Error: ${data.error || "Generation failed."}`);
      return;
    }

    addImageMessage(data.imageBase64, data.mimeType, prompt);
    stats.imgs++;
    saveStats();
    updateStats();
    statusBox.textContent = `\uD83D\uDDBC\uFE0F Image ready · ${data.model}`;
  } catch (err) {
    typingEl.remove();
    addMessage("assistant", `\u26A0\uFE0F ${err.message}`);
  }
}

// ── Error helpers ─────────────────────────────────────────────────
function friendlyError(raw = "") {
  if (raw.includes("429") || raw.includes("quota") || raw.includes("Too Many Requests"))
    return "\u23F3 Rate limit hit. Your free Gemini quota is used up — please wait ~1 minute and try again.";
  if (raw.includes("403") || raw.includes("API_KEY"))
    return "\uD83D\uDD11 API key error. Check GOOGLE_API_KEY in your .env file.";
  if (raw.includes("503") || raw.includes("overloaded"))
    return "\uD83D\uDD04 Google's servers are busy — try again in a few seconds.";
  return `\u26A0\uFE0F ${raw}`;
}

// ── Config ────────────────────────────────────────────────────────
async function loadConfig() {
  try {
    const res = await fetch("/api/config");
    if (!res.ok) throw new Error();
    statusBox.textContent = "✦ Powered by Gemini 2.5 Flash & Pollinations ❤️";
  } catch {
    statusBox.textContent = "Server unavailable.";
  }
}

// ── Message rendering ─────────────────────────────────────────────
function addMessage(role, content, options = {}) {
  const persist = options.persist !== false;
  const bubble = document.createElement("article");
  bubble.className = `message ${role}`;
  bubble.textContent = content;
  chatEl.appendChild(bubble);
  chatEl.scrollTop = chatEl.scrollHeight;
  if (persist && (role === "user" || role === "assistant")) {
    messages.push({ role, content });
  }
  return bubble;
}

function addImageMessage(base64, mimeType, prompt) {
  const bubble = document.createElement("article");
  bubble.className = "message assistant image-message";

  const caption = document.createElement("p");
  caption.className = "image-caption";
  caption.textContent = `\uD83D\uDDBC\uFE0F "${prompt}"`;

  const img = document.createElement("img");
  img.src = `data:${mimeType};base64,${base64}`;
  img.alt = prompt;
  img.className = "generated-image";

  const dl = document.createElement("a");
  dl.href = img.src;
  dl.download = "chatxyz-image.png";
  dl.className = "image-download-btn";
  dl.textContent = "\u2B07 Download";

  bubble.appendChild(caption);
  bubble.appendChild(img);
  bubble.appendChild(dl);
  chatEl.appendChild(bubble);
  chatEl.scrollTop = chatEl.scrollHeight;
  messages.push({ role: "assistant", content: `[Generated image for: ${prompt}]` });
}

// ── Start ─────────────────────────────────────────────────────────
init();
