# DailyTaskBot

Small chatbot starter for daily productivity tasks (planning, prioritizing, drafting short messages).

## Which API key to use?

- Use an `OPENAI_API_KEY` from `https://platform.openai.com/api-keys` if you want OpenAI models.
- OpenAI API is generally paid usage (pay-as-you-go). There is no permanent free OpenAI API key.
- If you want free usage, run locally with `Ollama` instead (no API key needed).

## Quick start

1. Install dependencies:

```powershell
npm install
```

2. Create env file:

```powershell
Copy-Item .env.example .env
```

3. Choose one provider in `.env`:

- `CHAT_PROVIDER=ollama` for free local mode
- `CHAT_PROVIDER=openai` to use OpenAI API

4. If using OpenAI, set:

```env
OPENAI_API_KEY=sk-your-real-key
OPENAI_MODEL=gpt-5-mini
```

5. Start app:

```powershell
npm start
```

Open: `http://localhost:3000`

## Ollama setup (free option)

1. Install Ollama from `https://ollama.com/download`.
2. Pull a model:

```powershell
ollama pull llama3.2
```

3. Keep Ollama running, then use:

```env
CHAT_PROVIDER=ollama
OLLAMA_MODEL=llama3.2
```

## Project structure

- `server.js`: backend API (`/api/chat`, `/api/config`)
- `public/index.html`: UI
- `public/app.js`: client logic
- `public/styles.css`: styles
